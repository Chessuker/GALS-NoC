`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/03/2026 10:35:35 PM
// Design Name: 
// Module Name: vc_port_arbiter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// =====================================================================
// VC Port Arbiter (Strict Priority with Packet-Level Anti-Starvation)
// =====================================================================
module vc_port_arbiter #(
    parameter PORTS = 4,
    parameter int STARVE_LIMIT = 64
)(
    input  logic clk,
    input  logic rst_n,

    input  logic [PORTS-1:0] valid_vc1,
    input  logic [PORTS-1:0] tlast_vc1,
    output logic [PORTS-1:0] grant_vc1,

    input  logic [PORTS-1:0] valid_vc0,
    input  logic [PORTS-1:0] tlast_vc0,
    output logic [PORTS-1:0] grant_vc0,

    input  logic             ready_out_vc1,
    input  logic             ready_out_vc0,
    output logic             ready_vc1, 
    output logic             ready_vc0  
);

    logic [PORTS-1:0] raw_grant_vc1;
    logic [PORTS-1:0] raw_grant_vc0;

    packet_arbiter #(.PORTS(PORTS)) arb_vc1 (
        .clk(clk), .rst_n(rst_n),
        .valid(valid_vc1), .tlast(tlast_vc1), 
        .ready(ready_vc1), .grant(raw_grant_vc1)
    );

    packet_arbiter #(.PORTS(PORTS)) arb_vc0 (
        .clk(clk), .rst_n(rst_n),
        .valid(valid_vc0), .tlast(tlast_vc0), 
        .ready(ready_vc0), .grant(raw_grant_vc0)
    );

    // =================================================================
    // Anti-Starvation State Machine + DEBUG PROBES
    // =================================================================
    logic [7:0] starve_cnt;
    logic       vc0_override;
    logic       vc1_is_active;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            starve_cnt   <= '0;
            vc0_override <= 1'b0;
        end else begin
            // 🟢 โหมด Override (ให้สิทธิ์ VC0)
            if (vc0_override) begin
                if (|raw_grant_vc0 && ready_out_vc0 && |(tlast_vc0 & raw_grant_vc0)) begin
                    vc0_override <= 1'b0;
                    starve_cnt   <= '0;
`ifdef SIM_DEBUG
                    // 🔍 ปริ้นท์บอกตอนที่คืนถนนให้ VC1
                    $display("[%0t ns] [ARB DEBUG] %m finished VC0 Packet. Releasing Override.", $time);
`endif
                end
            end 
            // 🔴 โหมดปกติ (VC1 นำ)
            else begin
                if (|valid_vc0 && vc1_is_active) begin
                    if (starve_cnt < 8'hFF) starve_cnt <= starve_cnt + 1'b1;
                end else if (!(|valid_vc0)) begin
                    starve_cnt <= '0; 
                end

                // ถ้าโกรธทะลุขีดจำกัด ให้เริ่มโหมด Override ทันที!
                if (starve_cnt >= STARVE_LIMIT) begin
                    vc0_override <= 1'b1;
`ifdef SIM_DEBUG
                    // 🔍 ปริ้นท์บอกตอนที่สั่งเบรก VC1 แบบ Cycle-Accurate!
                    $display("[%0t ns] [ARB DEBUG] %m Triggered VC0 Override! starve_cnt = %0d", $time, starve_cnt);
`endif
                end
            end
        end
    end

    assign vc1_is_active = |raw_grant_vc1 && !vc0_override; 

    // กั้นสัญญาณ
    assign grant_vc1 = vc1_is_active ? raw_grant_vc1 : '0;
    assign grant_vc0 = !vc1_is_active ? raw_grant_vc0 : '0;

    assign ready_vc1 = vc1_is_active ? ready_out_vc1 : 1'b0;
    assign ready_vc0 = !vc1_is_active ? ready_out_vc0 : 1'b0;

    // =================================================================
    // FORMAL VERIFICATION: พิสูจน์ว่า VC0 ไม่มีทาง starve เกิน STARVE_LIMIT
    // และ override ไม่มีทาง trigger ผิดจังหวะ / ค้างเป็น livelock
    // =================================================================
    `ifdef FORMAL
        reg f_past_valid = 1'b0;
        always @(posedge clk) f_past_valid <= 1'b1;

        // -----------------------------------------------------------
        // Compositional assumptions on the two inner packet_arbiter
        // instances: rely on properties packet_arbiter.sv already
        // proves (onehot grant, channel lock) instead of re-deriving
        // them here. This keeps the state space small.
        // -----------------------------------------------------------
        always @(*) begin
            if (rst_n && f_past_valid) begin
                if (raw_grant_vc1 != '0) assume($onehot(raw_grant_vc1));
                if (raw_grant_vc0 != '0) assume($onehot(raw_grant_vc0));
            end
        end

        always @(posedge clk) begin
            if (f_past_valid && $past(rst_n)) begin

                // -------------------------------------------------------
                // SAFETY 1: starve_cnt never exceeds STARVE_LIMIT while
                // override is off. If it did, override should already be
                // asserted (checked via the reset-timing note below: the
                // comparison in the RTL reads starve_cnt one cycle before
                // the increment lands, so the counter itself can be seen
                // at STARVE_LIMIT for exactly one cycle before override
                // fires on the following edge).
                // -------------------------------------------------------
                assert_starve_cnt_bounded: assert (starve_cnt <= STARVE_LIMIT);

                // -------------------------------------------------------
                // SAFETY 2: no false override. vc0_override can only be
                // 1 if starve_cnt reached STARVE_LIMIT on some earlier
                // cycle, or if we are still inside an in-progress
                // override episode.
                // -------------------------------------------------------
                if ($rose(vc0_override)) begin
                    assert_override_only_at_limit: assert($past(starve_cnt) >= STARVE_LIMIT);
                end

                // -------------------------------------------------------
                // SAFETY 3: while override is active, VC1 must not be
                // granted the port. Prevents a livelock where VC1 keeps
                // preempting VC0 back out from under the override.
                // -------------------------------------------------------
                if (vc0_override) begin
                    assert_no_vc1_during_override: assert(!vc1_is_active);
                end

                // -------------------------------------------------------
                // SAFETY 4: grant_vc1 and grant_vc0 are mutually
                // exclusive at the port-arbiter boundary (only one VC
                // may drive the shared output port per cycle).
                // -------------------------------------------------------
                assert_vc_mutex: assert(!(|grant_vc1 && |grant_vc0));

                // -------------------------------------------------------
                // SAFETY 5: starve_cnt holds (does not keep incrementing)
                // whenever VC0 is not being actively blocked by VC1 --
                // i.e. whenever vc1_is_active is 0 in normal mode, the
                // counter must not increment. This matches the RTL: the
                // counter only ever increments when (valid_vc0 &&
                // vc1_is_active), and only resets to 0 when valid_vc0
                // deasserts entirely.
                // -------------------------------------------------------
                if (!$past(vc0_override) && !$past(|valid_vc0 && vc1_is_active) && $past(|valid_vc0)) begin
                    assert_starve_holds_when_not_blocked: assert(starve_cnt == $past(starve_cnt) || vc0_override);
                end

                // -------------------------------------------------------
                // SAFETY 6: consistency check between the RTL's own
                // starve_cnt and this file's independent f_wait_cnt
                // tracker. Both count "VC0 valid but not granted" cycles;
                // they must never diverge by more than one override
                // episode's worth of slack. This catches any silent
                // logic bug in the increment/reset conditions of
                // starve_cnt that SAFETY 1/5 alone might miss.
                // -------------------------------------------------------
                if (!vc0_override && f_wait_cnt <= STARVE_LIMIT) begin
                    assert_wait_cnt_tracks_starve: assert(starve_cnt >= f_wait_cnt || f_wait_cnt == 0);
                end

                // -------------------------------------------------------
                // LIVENESS (bounded): if VC0 has been continuously
                // waiting (valid_vc0 asserted, no progress) for more than
                // STARVE_LIMIT+2 cycles while override has not fired,
                // that is a contradiction -- starve_cnt saturates at
                // STARVE_LIMIT (see SAFETY 1) and override must have
                // latched by the cycle after. The +2 margin covers the
                // one-cycle read-before-increment lag in the RTL plus
                // the registration delay of vc0_override itself.
                // -------------------------------------------------------
                if (f_wait_cnt > (STARVE_LIMIT + 2)) begin
                    assert_bounded_starvation: assert(vc0_override || $past(vc0_override));
                end
            end
        end

        // Free-running helper counter (formal-only): counts consecutive
        // cycles where VC0 has data waiting but has not been granted.
        // Resets whenever VC0 makes progress or has nothing queued.
        logic [15:0] f_wait_cnt;
        always_ff @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin
                f_wait_cnt <= '0;
            end else if (|grant_vc0 && ready_vc0) begin
                f_wait_cnt <= '0;
            end else if (!(|valid_vc0)) begin
                f_wait_cnt <= '0;
            end else begin
                f_wait_cnt <= f_wait_cnt + 1'b1;
            end
        end
    `endif

endmodule